import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportNG {
	
	public static ExtentReports ExtentReports ()
	{//reposnible where report should be created
		String path=System.getProperty("user.dir")+"\\reports\\index.html";
		ExtentSparkReporter r=new ExtentSparkReporter(path);
		r.config().setReportName("Automation report");
		r.config().setDocumentTitle("results");
		
		ExtentReports extent=new ExtentReports();
		extent.attachReporter(r);
		extent.setSystemInfo("tester", "masoome");
		return extent;
	}

}
