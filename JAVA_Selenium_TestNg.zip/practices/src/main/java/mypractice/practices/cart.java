package mypractice.practices;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class cart extends Abstract {
	WebDriver driver;
	
	public cart(WebDriver driver)
	
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//li[@class='totalRow']/button")
	WebElement buttons;
	
	@FindBy(css="input[placeholder='Select Country']")
	WebElement holder;
	
	@FindBy(xpath="//a[@class='btnn action__submit ng-star-inserted']")
	WebElement submit;
	
	public void buttons()
	{
		buttons.click();
	}
	
	public void country() 
	{
		holder.sendKeys("ind");
		
	}
	public void su() {
		submit.click();
	}
	
	public void p() throws InterruptedException
	{
		Thread.sleep(4000);
	}

}

