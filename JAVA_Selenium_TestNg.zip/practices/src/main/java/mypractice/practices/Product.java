package mypractice.practices;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product extends Abstract{
WebDriver driver;
	
	public  Product (WebDriver driver)
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className="mb-3")
	List<WebElement> products;
	
	By products1=By.className("mb-3");
	By addto=By.cssSelector(".card-body button:last-of-type");
	By toastMessage=By.id("toast-container");
	By dis=By.className("ng-animating");
	
	public List<WebElement> getProducts()
	{
		waitforElement(products1);
		return products;
	}
	
	public WebElement Productname(String productName) {
		WebElement prod= getProducts().stream().filter(product->
		product.findElement(By.cssSelector("b")).getText().equals(productName)).findFirst().orElse(null);
		return prod;
	}
	
	public void addProductTocart(String productName)
	{
		WebElement prod=Productname(productName);
		prod.findElement(By.cssSelector(".card-body button:last-of-type")).click();
		waitforElement(toastMessage);
		waitfoElementDisappear(dis);
	}

}

