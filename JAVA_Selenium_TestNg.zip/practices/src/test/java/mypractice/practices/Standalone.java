package mypractice.practices;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
@Test
public class Standalone extends Base {
	public void submitorder() throws IOException

	{
		// TODO Auto-generated method stub
	
		String productName="ZARA COAT 3";
		Landingpage landing=launchApp();
		//Landingpage landing=new Landingpage(driver);
		landing.login("fathimahussain22@gmail.com", "Yaali78612@");
		Product p1=new Product(driver);
		List<WebElement>products= p1.getProducts();
		p1.addProductTocart(productName);
		p1.gotocart();
		List<WebElement> cart=driver.findElements(By.xpath("//div[@class='cartSection']/h3"));
		for(int i=0;i<cart.size();i++)
		{
			String e=cart.get(i).getText();
			if(e.equalsIgnoreCase(productName))
			{
				Assert.assertEquals(productName,e);
			}
		}
		cart c=new cart(driver);
		c.buttons();
		c.country();
		try {
			c.p();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Thread.sleep(4000);
		List<WebElement> country=driver.findElements(By.xpath("//span[@class='ng-star-inserted']"));
		for(int i=0;i<country.size();i++)
		{
			String X=country.get(i).getText();
			System.out.println(c);
			if(X.equalsIgnoreCase("India"))
			{
			driver.findElements(By.xpath("//span[@class='ng-star-inserted']")).get(i).click();
			break;
						
			}
		}
		c.su();
		String text=driver.findElement(By.xpath("//h1[@class='hero-primary']")).getText();
		Assert.assertEquals(text, "THANKYOU FOR THE ORDER.");
		}

		
		

		}


